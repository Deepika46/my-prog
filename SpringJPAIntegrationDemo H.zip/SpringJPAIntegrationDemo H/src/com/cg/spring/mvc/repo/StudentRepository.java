package com.cg.spring.mvc.repo;

import com.cg.spring.mvc.beans.Student;

public interface StudentRepository {
	public Student addStudent(Student student);

}
