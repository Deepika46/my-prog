package com.cg.spring.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.spring.mvc.beans.Student;
import com.cg.spring.mvc.repo.StudentRepository;
@Service
@Transactional
public class StudentServiceImpl implements StudentService {
  @Autowired
  StudentRepository repo;
  public StudentRepository getRepo() {
	return repo;
}

public void setRepo(StudentRepository repo) {
	this.repo = repo;
}
 @Override
	public Student addstudent(Student student) {
		return repo.addStudent(student);
		}	
}

