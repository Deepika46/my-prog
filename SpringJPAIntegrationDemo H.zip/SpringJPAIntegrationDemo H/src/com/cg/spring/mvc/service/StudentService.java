package com.cg.spring.mvc.service;

import com.cg.spring.mvc.beans.Student;

public interface StudentService {
	public Student addstudent(Student student);

}
