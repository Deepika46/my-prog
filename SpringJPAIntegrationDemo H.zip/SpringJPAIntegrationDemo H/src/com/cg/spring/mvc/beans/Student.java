package com.cg.spring.mvc.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
@Entity
@Table(name="student")
public class Student {
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
	
	private int studentId;
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	@Pattern(regexp="[A-Z][a-z]{4,}",
			message="Name should start with uppercase and have minimum 4 alphabets")
	private String firstName;
	private String lastName;
	@Min(value=20,message="Age should be >20")
	@Max(value=50,message="Age should be <50")
	private int Age;
	@Pattern(regexp="[0-9]{10}",message="Mobile number not exceed 10 digits")
	
	private String Mobileno;
	@NotNull(message="please select the gender")
	private String gender;
	@NotNull(message="please select the city")
	private String city;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getMobileno() {
		return Mobileno;
	}
	public void setMobileno(String mobileno) {
		Mobileno = mobileno;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	

}
