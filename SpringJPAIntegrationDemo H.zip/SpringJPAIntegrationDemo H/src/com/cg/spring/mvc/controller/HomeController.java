package com.cg.spring.mvc.controller;

import java.time.LocalDate;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.spring.mvc.beans.Student;
import com.cg.spring.mvc.service.StudentService;


@Controller
public class HomeController {
	@Autowired
	StudentService service;
	
	public StudentService getService() {
		return service;
	}
	public void setService(StudentService service) {
		this.service = service;
	}
	@RequestMapping("/displayDate")
	public String  displayDate(Model model) {
		System.out.println("in display date method..");
		LocalDate date=LocalDate.now();
		model.addAttribute("today",date);
		return "Home";
	}
	@RequestMapping("showLoginPage")
	public String getLoginPage() {
		return "Login";
	}
	
		@RequestMapping("loginaction")
		public String validateUser(Model model ,
				@RequestParam("Username") String uname,
				@RequestParam("Password")  String pass) {
			if(uname.equals("Harsha")&&pass.equals("harsha123")){
				model.addAttribute("successMsg","Welcome to Home Page");
			    //model.addAttribute("userName",uname);
				return "Home";
			}
			else
			{
				model.addAttribute("errorMsg","Invalid Username/Password");
			
					
			return "Error";
		}
	}
 @RequestMapping("showRegistrationPage")
 public String validateRegistrationPge(Model model) {
	 Student student=new Student();
	 model.addAttribute("studentBean",student);
	 return "Registration";
	 
 
}
		
 @RequestMapping("registerAction")
 public String registerUser(Model model,
 @ModelAttribute("studentBean")@Valid Student student,BindingResult result){
	 if(result.hasErrors())
		 {
		  return "Registration";
		 }else {
			 student=service.addstudent(student);
	      
			 model.addAttribute("student",student);
			 model.addAttribute("successMsg","Student Added");
	          return "success";
   
		 }
 }
}	
		  
	
