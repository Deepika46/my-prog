package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exceptions.TakeCareExceptions;
import com.capgemini.tcc.logger.TakeCareLogger;



public class PatientDAO implements IPatientDAO {

	Connection conn;
	Logger logger;
	
	//Generate the field patientId
	@Override
	public int generatePatientId() throws TakeCareExceptions {
		
		logger = TakeCareLogger.getLogger();
		String sql = "SELECT Patient_Id_Seq.NEXTVAL FROM DUAL";
		conn = DBUtil.getConnection();
		
			Statement st;
			try {
				st = conn.createStatement();
				ResultSet rst = st.executeQuery(sql);
				rst.next();
				return rst.getInt(1);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error("Problem in generating Patient ID"+e.getMessage());
				throw new TakeCareExceptions("Problem in generating Patient ID");
			}//end of the catch		
	}//end of generatePatientId() 
	
	
	//Validate entered data
	public boolean validatePatient(PatientBean patient) throws TakeCareExceptions {
				
		if(!patient.getPhone().matches("[0-9]{10}")) {
			throw new TakeCareExceptions("Phone Number should contain 10 digits");
		}
		
		if(patient.getAge()<0) {
			throw new TakeCareExceptions("Patient age sholud be greater than 0");
		}		
		
		return false;
		
	}//end of the validatePatient
	
	
	
	
	/*method to add the patient details which will
	return the generated patient id on successfull 
	insertion of data in the database*/
	@Override
	public int addPatientDetails(PatientBean patient) throws TakeCareExceptions {
		
		Scanner sc  = new Scanner(System.in);
		System.out.println("Enter the name of the Patient");
		String patientName = sc.next();
		System.out.println("Enter Patient Age");
		int patientAge = sc.nextInt();
		System.out.println("Enter Patient phone number");
		String patientPhone = sc.next();
		System.out.println("Enter Desciption");
		sc.nextLine();
		String deseaseDesciption = sc.nextLine();
		
		//Store data in the object so that we can return PatientBean Object if required for future use
		
		patient.setPatientId(generatePatientId());
		patient.setPatientName(patientName);
		patient.setAge(patientAge);
		patient.setPhone(patientPhone);
		patient.setDescription(deseaseDesciption);
		patient.setConsultationDate(LocalDate.now());
		
		if(validatePatient(patient));
		{		
			String sql = "INSERT INTO Patient VALUES(?,?,?,?,?,?)";
			Connection conn =DBUtil.getConnection();
			
			try {
				
				//Convert sql statement to proper format
				PreparedStatement pst = conn.prepareStatement(sql);
				pst.setInt(1, patient.getPatientId());
				pst.setString(2, patient.getPatientName());
				pst.setInt(3, patient.getAge());
				pst.setString(4, patient.getPhone());
				pst.setString(5, patient.getDescription());
				pst.setObject(6, Date.valueOf(patient.getConsultationDate()));
				
				//Execute & Insert data in sql databse
				pst.executeUpdate();
				logger.info("Patient Information stored successfully for "+patient.getPatientId());
			} catch (SQLException e) {
				logger.error("Problem in inserting Patient Details"+e.getMessage());
				throw new TakeCareExceptions("Problem in inserting Patient Details");
			}//end of the catch
		
		}
		
		return patient.getPatientId();
	}//end of addPatientDetails

	

}
