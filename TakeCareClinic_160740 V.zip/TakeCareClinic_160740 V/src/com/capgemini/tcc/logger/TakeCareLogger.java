package com.capgemini.tcc.logger;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.tcc.exceptions.TakeCareExceptions;

public class TakeCareLogger {

	//Create object of the Logger
	static Logger Logger;
	public static Logger getLogger() throws TakeCareExceptions {
		//If Logger is not found
		if(Logger==null) {
			Logger = Logger.getLogger("RegLogger");
			FileInputStream fin;
			try {
				fin = new FileInputStream("./resourse/log4j.properties");
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				throw new TakeCareExceptions("Property File for logger not found"+e1.getMessage());
			}
			//Configure Logger file
			PropertyConfigurator.configure(fin);
						
		}//end of the if
				
		return Logger;
	}//end of the getLogger()
	
}//end of class TakeCareLogger
