package com.capgemini.tcc.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exceptions.TakeCareExceptions;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		//Create Object of service class to access services
		IPatientService pser = new PatientService();
		
		//User Interface using do_while & switch_case
		do {
		
			System.out.println("Menu");
			System.out.println("1. Add Patient Information");
			System.out.println("2. Exit");
			
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			
			switch(choice) {
			
			case 1:
				PatientBean patient = new PatientBean();
				//Add Patient Information
				try {
					int pid = pser.addPatientDetails(patient);
					System.out.println("Patient Information stored successfully for "+pid);
				} catch (TakeCareExceptions e) {
					// TODO Auto-generated catch block
					System.err.println("Can't Add New Patient"+e.getMessage());
				}
				break;
			case 2:
				//Exit
				System.out.println("Thank You");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Choice");
			}
			
		}while(true);
	}//end of the main

}//end of the Client Class
