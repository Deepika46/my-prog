package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exceptions.TakeCareExceptions;

public interface IPatientService {
	
	/*method to add the patient details which will
	return the generated patient id on successfull 
	insertion of data in the database*/
	int addPatientDetails(PatientBean patient) throws TakeCareExceptions;

}
