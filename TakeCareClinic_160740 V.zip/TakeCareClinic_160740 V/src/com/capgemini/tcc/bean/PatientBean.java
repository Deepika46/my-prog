package com.capgemini.tcc.bean;

import java.time.LocalDate;

public class PatientBean {

	/*CREATE TABLE Patient(
			patient_id NUMBER PRIMARY KEY, 
			patient_name VARCHAR2(20),age NUMBER(3), 
			phone VARCHAR2(10), 
			description VARCHAR2(80),
			consultation_date DATE);*/  
	private int patientId;
	private String patientName;
	private int age;
	private String phone;
	private String description;
	private LocalDate consultationDate;
	
	//default constructor
	public PatientBean() {
		// TODO Auto-generated constructor stub
	}

	//Parameterized constructor
	public PatientBean(int patientId, String patientName, int age, String phone, String description,
			LocalDate consultationDate) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.age = age;
		this.phone = phone;
		this.description = description;
		this.consultationDate = consultationDate;
	}

	//Getters & Setters
	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getConsultationDate() {
		return consultationDate;
	}

	public void setConsultationDate(LocalDate consultationDate) {
		this.consultationDate = consultationDate;
	}

	//to_String method for Printing the fields of the object
	@Override
	public String toString() {
		return "PatientBean [patientId=" + patientId + ", patientName=" + patientName + ", age=" + age + ", phone="
				+ phone + ", description=" + description + ", consultationDate=" + consultationDate + "]";
	}
	
}
