package com.capgemini.tcc.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exceptions.TakeCareExceptions;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

class TakeCaseTest {

	IPatientService pser = new PatientService();
	
	@Test
	void TestCustomerInsertion() {
		int pid = 0;
		PatientBean pb = new PatientBean();
		try {
			//at the time of testing insert valid data in the console
			pid = pser.addPatientDetails(pb);
			
		} catch (TakeCareExceptions e) {
			
			System.err.println("Can't Insert data in the test"+e.getMessage());
		}
		
		//Check whether the ID is properly generated or not after insertion
		assertTrue(pid>1000);
		
	}//end of the validateCustomerInsertion

}//end of the TakeCaseTest
