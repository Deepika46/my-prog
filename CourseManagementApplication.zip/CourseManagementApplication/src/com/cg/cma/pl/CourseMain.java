package com.cg.cma.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.cma.dto.Course;
import com.cg.cma.exceptions.CourseException;
import com.cg.cma.service.CourseService;
import com.cg.cma.service.CourseServiceImpl;

public class CourseMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		CourseService cser = new CourseServiceImpl();
		
		do {
			System.out.println("Menu");
			System.out.println("1. Show all courses");
			System.out.println("2. Add new course");
			System.out.println("3. Update a course");
			System.out.println("4. Delete a course");
			System.out.println("5. Exit");
			System.out.println("Enter your choice : ");
			int choice = sc.nextInt();
			
			switch(choice) {
			case 1:
				List<Course> clist;
				try {
					clist = cser.getAllCourses();
					for (Course c : clist) {
						System.out.println(c);					
					}
					
				} catch (CourseException e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}			
				break;
			case 2:
				Course c  = new Course();
				System.out.println("Enter course title:");
				c.setCourseTitle(sc.next());
				System.out.println("Enter course duration : ");
				c.setDuration(sc.nextInt());
				System.out.println("Enter course fees : ");
				c.setFees(sc.nextDouble());
				
				try {
					if(cser.validate(c)) {
						long cid = cser.insertCourse(c);
						System.out.println("Course added with id "+cid);
					}
				} catch (CourseException e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
				break;
			case 3:
				Course course = new Course(); 
				try {
					cser.updateCourse(course);
				} catch (CourseException e1) {
					// TODO Auto-generated catch block
					System.err.println("Can't Update");
				}
				break;
			case 4:
				System.out.println("Enter Customer id : ");
				int cid = sc.nextInt();
				try {
					boolean delcourse = cser.deleteCourse(cid);
					if(delcourse) {
						System.out.println("Successfully deleted record with Customer ID "+cid);
					}
				} catch (CourseException e) {
					// TODO Auto-generated catch block
					System.err.println("No such Employee id");
				}
				break;
			case 5:
				System.out.println("Thank You");
				System.exit(0);			
			}
		}while(true);
	}

}
