package com.cg.cma.service;

import java.util.List;

import com.cg.cma.dao.CourseDAOImpl;
import com.cg.cma.dao.CouseDAO;
import com.cg.cma.dto.Course;
import com.cg.cma.exceptions.CourseException;

public class CourseServiceImpl implements CourseService {
	
	private CouseDAO cdao = new CourseDAOImpl();
	

	@Override
	public long insertCourse(Course course) throws CourseException {
		// TODO Auto-generated method stub
		return cdao.insertCourse(course);
	}

	@Override
	public List<Course> getAllCourses() throws CourseException {
		// TODO Auto-generated method stub
		return cdao.getAllCourses();
	}

	@Override
	public boolean updateCourse(Course course) throws CourseException {
		// TODO Auto-generated method stub
		return cdao.updateCourse(course);
	}

	@Override
	public boolean deleteCourse(long courseId) throws CourseException {
		// TODO Auto-generated method stub
		return cdao.deleteCourse(courseId);
	}
	
	@Override
	public boolean validate(Course course) throws CourseException{
		if(course.getDuration()<=0 || course.getDuration()>100) {
			throw new CourseException("Duration Should be more than 1 and less than 100");
		}
		if(course.getFees()<=0) {
			throw new CourseException("Fees should not be negative");
		}
		if(!course.getCourseTitle().matches("[A-Za-z0-9]{3,}")) {
			throw new CourseException("Course title should not include special character");
		}
		return true;
	}

}
