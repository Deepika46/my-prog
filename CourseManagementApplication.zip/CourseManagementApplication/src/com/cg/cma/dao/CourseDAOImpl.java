package com.cg.cma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.cma.dto.Course;
import com.cg.cma.exceptions.CourseException;

public class CourseDAOImpl implements CouseDAO {

	Connection conn;
	
	private long generateCourseId() throws CourseException{
		conn = DBUtil.getConnection();
		String sql = "SELECT seq_course_id.NEXTVAL FROM DUAL";
		
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			rst.next();
			return rst.getLong(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new CourseException("Problem in generation course id "+e.getMessage());
		}
	}
	
	@Override
	public long insertCourse(Course course) throws CourseException {
		// TODO Auto-generated method stub
		
		String sql = "INSERT INTO course VALUES(?,?,?,?)";
		course.setCourse_id(generateCourseId());
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setLong(1, course.getCourse_id());
			pst.setString(2, course.getCourseTitle());
			pst.setDouble(3, course.getFees());
			pst.setInt(4, course.getDuration());
			pst.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new CourseException("Problem in inserting the details "+e.getMessage());
		}
		return course.getCourse_id();
	}

	@Override
	public List<Course> getAllCourses() throws CourseException {
		// TODO Auto-generated method stub
		
		String sql = "SELECT course_id, course_title, fees, duration FROM course";
		ArrayList<Course> clist = new ArrayList<>();
		conn = DBUtil.getConnection();
		Statement st;
		try {
			st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			while(rst.next()) {
				Course c = new Course();
				c.setCourse_id(rst.getLong("course_id"));
				c.setCourseTitle(rst.getString("course_title"));
				c.setFees(rst.getDouble("fees"));
				c.setDuration(rst.getInt("duration"));
				clist.add(c);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new CourseException("Problem in the fetching details"+e.getMessage());
		}
		
		
		return clist;
	}

	@Override
	public boolean updateCourse(Course course) throws CourseException {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Customer ID : ");
		int cid = sc.nextInt();
		boolean flag=true;
		
		do {
			System.out.println("Select the Choice");
			System.out.println("1. Title");
			System.out.println("2. Fees");
			System.out.println("3. Duration");
			System.out.println("4. Exit");
			
			
			int choice = sc.nextInt();
			
			switch(choice) {
		
				case 1:
					String sql = "UPDATE course SET course_title=? where course_id=?";
					conn = DBUtil.getConnection();
					System.out.println("Enter the Title : ");
					String title = sc.next();
					PreparedStatement pst;
					try {
						pst = conn.prepareStatement(sql);
						pst.setString(1, title);
						pst.setLong(2, cid);
						pst.executeUpdate();
					} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new CourseException("Problem in updating the title "+e.getMessage());
					}					
					
					break;
					
				case 2:
					String sql2 = "UPDATE course SET fees=? where course_id=?";
					conn = DBUtil.getConnection();
					System.out.println("Enter the Fees : ");
					Double fees = sc.nextDouble();
					
					PreparedStatement pst1;
					try {
						pst1 = conn.prepareStatement(sql2);
						pst1.setDouble(1, fees);
						pst1.setLong(2, cid);
						pst1.executeUpdate();
					} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new CourseException("Problem in updating the fees "+e.getMessage());
					}					
					break;
					
				case 3:
					String sql3 = "UPDATE course SET duration=? where course_id=?";					
					conn = DBUtil.getConnection();
					System.out.println("Enter the Duration : ");
					int duration = sc.nextInt();			
					
					PreparedStatement pst2;
					try {
						pst2 = conn.prepareStatement(sql3);
						pst2.setInt(1, duration);
						pst2.setLong(2, cid);
						pst2.executeUpdate();
					} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new CourseException("Problem in updating the duration "+e.getMessage());
					}					
					break;
					
				case 4:
					System.out.println("Record with id "+cid+" updated successfully" );
					flag=false;
					
					
			}
			
		}while(flag);
		return flag;	
		
	}

	@Override
	public boolean deleteCourse(long courseid) throws CourseException {
		// TODO Auto-generated method stub
		
		String sql = "DELETE FROM course where course_id=?";
		conn = DBUtil.getConnection();
		
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(sql);
			pst.setLong(1, courseid);
			pst.executeQuery();
			return true;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			throw new CourseException("Problem in the deleting details"+e1.getMessage());
		}
		
		
	}

}
