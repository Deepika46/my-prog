package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.exceptions.MobileException;
import com.cg.ma.dto.Mobile;
import com.cg.ma.dto.Purchase;
import com.cg.ma.exceptions.MobileException;

public interface MobileDao {

	long insertCustomer(Purchase purchase) throws MobileException;
	List <Mobile> getAllMobiles() throws MobileException;
	boolean deleteMobile(long mobId) throws MobileException;
	boolean searchMobile(double mobPrice) throws MobileException;
	boolean updateMobile(long mobId) throws MobileException;
	boolean validateCourseId (long mobId) throws MobileException;

}
