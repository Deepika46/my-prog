package com.cg.ma.dao;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

import com.cg.ma.dao.DBUtil;
import com.cg.ma.exceptions.MobileException;
import com.cg.ma.dto.Mobile;
import com.cg.ma.dto.Purchase;
import com.cg.ma.exceptions.MobileException;

public class MobileDaoImpl implements MobileDao {
	private Connection conn;

	private long generateCourseId() throws MobileException
	{
		conn=DBUtil.getConnection();
		String sql="SELECT seq_purchase_id.NEXTVAL FROM DUAL";
		
		try {
			Statement st= conn.createStatement();
			ResultSet rst=st.executeQuery(sql);
			rst.next();
			return rst.getLong(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		throw new MobileException("Problem in generation of course id" + e.getMessage());
		
		}
	
	}
	
	@Override
	public long insertCustomer(Purchase purchase) throws MobileException {
	
		String sql="INSERT INTO purchasedetails VALUES(?,?,?,?,?,?) ";
		purchase.setpId(generateCourseId());
		conn=DBUtil.getConnection();
		
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setLong(1, purchase.getpId());
			pst.setString(2, purchase.getcName());
			pst.setString(3, purchase.getMailId());
			pst.setInt(4, purchase.getPhone());
			pst.setString(5, purchase.getpDate());
			pst.setLong(6, purchase.getMobId());
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MobileException("Problem in inserting the details" + e.getMessage());

		}
		
		
		return purchase.getpId();
		
		
	}

	@Override
	public List<Mobile> getAllMobiles() throws MobileException {
		// TODO Auto-generated method stub
		
		String sql="SELECT * FROM mobiles";
		ArrayList<Mobile> mlist = new ArrayList<>();
		conn = DBUtil.getConnection();
		Statement st;
		try {
			st = conn.createStatement();
			ResultSet rst=st.executeQuery(sql);
		 
		while(rst.next())
		{
			Mobile m= new Mobile();
			m.setMobId(rst.getLong("mobileid"));
			m.setMobName(rst.getString("name"));
			m.setMobPrice(rst.getDouble("price"));
			m.setMobQuant(rst.getString("quantity"));
			mlist.add(m);
		}
			}
			
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MobileException("Problem in the fetching details"+e.getMessage());

		}
		
		
		return mlist;
	}

	@Override
	public boolean deleteMobile(long mobId) throws MobileException {
		// TODO Auto-generated method stub
		
		//System.out.println("Deleted");
		
		
		String sql="DELETE FROM mobiles where mobileid=?";
		conn=DBUtil.getConnection();
		
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setLong(1, mobId);
			pst.executeUpdate();
			return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MobileException("Problem in the deleting details"+e.getMessage());
		}
		
			
		
	}

	@Override
	public boolean searchMobile(double mobPrice) throws MobileException {
		// TODO Auto-generated method stub
		
		String sql="SELECT mobileid,name,quantity from mobiles where price>?";
		conn=DBUtil.getConnection();
		
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			
			
			pst.setDouble(1, mobPrice);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{				
				int a=rs.getInt("mobileid");
				String b=rs.getString("name");
				String c=rs.getString("quantity");
				System.out.println(a+"  ||  "+b+"  ||  "+c+"  ||  ");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MobileException("Problem in searching mobile details based on price"+e.getMessage());
			
		}
		
		
		return true;
	}

	public boolean updateMobile(long mobId) throws MobileException {
		// TODO Auto-generated method stub
	String sql="UPDATE mobiles set quantity=quantity-1 where mobileid=?";
	conn=DBUtil.getConnection();
	try {
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setLong(1,mobId);
		pst.executeUpdate();
		return false;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		throw new MobileException("Problem in the updating details"+e.getMessage());
	}
	}
	
	public boolean validateCourseId(long mobId) throws MobileException {
		// TODO Auto-generated method stub
		String sql = "SELECT count(*) FROM mobile where course_id=?";
		conn = DBUtil.getConnection();
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(sql);
			pst.setLong(1, mobId);
			ResultSet rst = pst.executeQuery();
			if(rst.next()) {
				int count = rst.getInt(1);
				if(count==1) {
					return true;
				}
				else {
					throw new MobileException("Invalid Course ID");
				}
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Problem in the validating course"+e.getMessage());
		}
		
		
		return false;
	}
	
	

}
