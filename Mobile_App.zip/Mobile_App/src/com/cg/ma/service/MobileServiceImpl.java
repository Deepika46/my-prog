package com.cg.ma.service;

import java.util.List;

import com.cg.ma.dao.MobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.dto.Mobile;
import com.cg.ma.dto.Purchase;
import com.cg.ma.exceptions.MobileException;

public class MobileServiceImpl implements MobileService {
	
	private MobileDao mdao = new MobileDaoImpl();
	//private Purchase p = new Purchase();
	

	@Override
	public long insertCustomer(Purchase purchase) throws MobileException {
		// TODO Auto-generated method stub
		mdao.insertCustomer(purchase);
		return purchase.getpId();
	}

	@Override
	public List<Mobile> getAllMobiles() throws MobileException {
		// TODO Auto-generated method stub
		return mdao.getAllMobiles();
	}

	@Override
	public boolean deleteMobile(long mobId) throws MobileException {
		// TODO Auto-generated method stub
		return mdao.deleteMobile(mobId);
	}

	@Override
	public boolean searchMobile(double mobPrice) throws MobileException {
		// TODO Auto-generated method stub
		return mdao.searchMobile(mobPrice);
		
	}

	@Override
	public boolean updateMobile(long mobId) throws MobileException {
		// TODO Auto-generated method stub
		return mdao.updateMobile(mobId);
	}

	@Override
	public boolean validateRegistrationDetails(Purchase purchase) throws MobileException {
		// TODO Auto-generated method stub
		
		if(!purchase.getcName().matches("[A-Z][a-z]{20}")) {
			throw new MobileException("Student Name should start start with capital letter");
			
		}
		
		String a=Integer.toString(purchase.getPhone());
		if(!a.matches("[0-9]{10}")) {
			throw new MobileException("Phone Number should contain 10 digits");
		}
		
		
		
		return true;
	}

}
