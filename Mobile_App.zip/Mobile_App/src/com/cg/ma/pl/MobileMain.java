package com.cg.ma.pl;

import java.sql.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.ma.dto.Mobile;
import com.cg.ma.dto.Purchase;
import com.cg.ma.exceptions.MobileException;
import com.cg.ma.service.MobileService;
import com.cg.ma.service.MobileServiceImpl;

public class MobileMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		MobileService mser=new MobileServiceImpl();
		
		do
		{
			System.out.println("Menu");
			System.out.println("1. Insert Customer Details : ");
			System.out.println("2. View All Mobile Details : ");
			System.out.println("3. Delete Mobile Detail : ");
			System.out.println("4. Search Mobile Details(on price) : ");
		//	System.out.println("5. Update Mobile Details : ");
			int choice = sc.nextInt();
			
			switch(choice)
			{
			case 1:
				Purchase p=new Purchase();
				System.out.println("Enter Customer Name: ");
				p.setcName(sc.next());
				System.out.println("Enter Email: ");
				p.setMailId(sc.next());
				System.out.println("Enter phone no: ");
				p.setPhone(sc.nextInt());
				System.out.println("Enter the date: ");
				p.setpDate(sc.next());
				System.out.println("Enter mobile Id: ");
				p.setMobId(sc.nextLong());
				
				try {
					if(mser.validateRegistrationDetails(p))
					{
					mser.insertCustomer(p);
					mser.updateMobile(p.getMobId());
					}
				} catch (MobileException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				break;
			case 2:
				List<Mobile> mlist;
				try
				{
					mlist = mser.getAllMobiles();
				
				for (Mobile mobile : mlist) {
					System.out.println(mobile);
				}
				
			}catch (MobileException e) {
				// TODO Auto-generated catch block
				System.err.println(e.getMessage());
			}			
			break;
			case 3: 
				System.out.println("enter mobile id : ");
				long mid=sc.nextLong();
				try {
				boolean delmobile=mser.deleteMobile(mid);
				if(delmobile) {
					System.out.println("successfully deleted record with id "+mid);
				}
				else
					System.out.println("Not found!");
				}catch (MobileException e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
				break;
			case 4:
				System.out.println("enter price : ");
				double mp=sc.nextDouble();
				try {
					boolean sermob=mser.searchMobile(mp);
					if(sermob)
						System.out.println("succefully found!!");
				}
				catch(MobileException e)
				{
				
					System.err.println("No such price");
				}
			/*case 5:
				System.out.println("enter mobId : ");
				long mi=sc.nextLong();
				try {
					boolean upmob=mser.updateMobile(mi);
					if(upmob)
						System.out.println("succefully updated!!");
				}
				catch(MobileException e)
				{
				
					System.err.println("No such id");
				}
				break;*/
		}
		}
		while(true);

}
}