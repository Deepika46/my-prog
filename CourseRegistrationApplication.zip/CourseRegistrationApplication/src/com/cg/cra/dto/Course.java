package com.cg.cra.dto;

public class Course {
	private long course_id;
	private String courseTitle;
	private double fees;
	private int duration;
	
	public Course() {
		// TODO Auto-generated constructor stub
	}

	public Course(long course_id, String courseTitle, double fees, int duration) {
		super();
		this.course_id = course_id;
		this.courseTitle = courseTitle;
		this.fees = fees;
		this.duration = duration;
	}

	public long getCourse_id() {
		return course_id;
	}

	public void setCourse_id(long course_id) {
		this.course_id = course_id;
	}

	public String getCourseTitle() {
		return courseTitle;
	}

	public void setCourseTitle(String courseTitle) {
		this.courseTitle = courseTitle;
	}

	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	@Override
	public String toString() {
		return "Course [course_id=" + course_id + ", courseTitle=" + courseTitle + ", fees=" + fees + ", duration="
				+ duration + "]";
	}
	
	
	

}
