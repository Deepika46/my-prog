package com.cg.cra.logger;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.cra.exceptions.RegistrationException;

public class RegistrationLogger {
	static Logger Logger;
	public static Logger getLogger() throws RegistrationException {
		if(Logger==null) {
			Logger = Logger.getLogger("RegLogger");
			FileInputStream fin;
			try {
				fin = new FileInputStream("./resource/log4j.properties");
			}catch (FileNotFoundException e) {
			throw new RegistrationException("Property file for logger "+"not found"+e.getMessage());
			};
			PropertyConfigurator.configure(fin);
			
		}
		return Logger;
	}

}
