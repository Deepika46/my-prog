package com.cg.cra.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.cg.cra.dto.Course;
import com.cg.cra.dto.Registration;
import com.cg.cra.exceptions.RegistrationException;
import com.cg.cra.service.RegistrationService;
import com.cg.cra.service.RegistrationServiceImpl;

public class RegistrationMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		RegistrationService rser = new RegistrationServiceImpl();
		do {
			try {
			List<Course> clist = rser.getAllCourses();
			if(clist.size()==0) {
				System.out.println("No course available");
			}else {
				for(Course c:clist) {
					System.out.println(c);
				}
			}
		}catch (RegistrationException e) {
			System.out.println(e.getMessage());
			break;
		}
			System.out.println("Menu");
			System.out.println("1. Register");
			System.out.println("2. Exit");
			System.out.println("Enter your choice:");
			int choice = sc.nextInt();
			switch(choice) {
			case 1: // Code for Register
				registerStudent(rser);
				break;
			case 2: System.exit(0);
			default: System.out.println("Invalid choice..");
			}

	}while(true);

}
	private static void registerStudent(RegistrationService rser) {
		Scanner sc = new Scanner(System.in);
	try {
		System.out.println("Enter course id to register from the above list");
		long courseid = sc.nextLong();
		
        if(rser.validateCourseId(courseid)) {
		System.out.println("Enter student Name :");
		String stName = sc.next();
		System.out.println("Enter Address :");
		String address = sc.next();
		System.out.println("Enter phone number :");
		String phone = sc.next();
		System.out.println("Enter registration dat in dd/mm/yyyy format");
		String dateStr = sc.next();
		Registration reg = new Registration();
		reg.setCourseId(courseid);
		reg.setStudentName(stName);
		reg.setAddress(address);
		reg.setPhoneNo(phone);
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		reg.setRegDate(LocalDate.parse(dateStr,format));
		if(rser.validateRegistrationDetails(reg)) {
			long regid = rser.register(reg);
			System.out.println("Successfully registered with registration id :"+regid);
		}
		
	}
	}
	catch (RegistrationException e) {
		System.out.println(e.getMessage());
	
	}
}
}