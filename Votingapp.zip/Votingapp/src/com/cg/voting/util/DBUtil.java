package com.cg.voting.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.voting.exceptions.VotingException;

public class DBUtil {
	static Connection connection;

	public static Connection obtainConnection() throws VotingException {
		try {
			InitialContext context = new InitialContext();
			DataSource source = (DataSource) context
					.lookup("java:/jdbc/ConPool");
			connection = source.getConnection();
		} catch (NamingException e) {
			throw new VotingException("Error while creating datascource::"
					+ e.getMessage());
		} catch (SQLException e) {
			throw new VotingException("Error while obtaining connection::"
					+ e.getMessage());
		}
		return connection;
	}
}


