package com.cg.voting.service;

import java.util.ArrayList;

import com.cg.voting.bean.Person;
import com.cg.voting.exceptions.VotingException;

public class VotingServiceImpl implements VotingService {

	@Override
	public ArrayList<String> getName() throws VotingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<String> search(String Name) throws VotingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insert(Person person, int personId) throws VotingException {
		// TODO Auto-generated method stub
		return 0;
	}

}
