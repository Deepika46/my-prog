package com.cg.voting.bean;

public class Person {
	private String age;
	private String name;
	private String person_id;
	public Person()
	{
	
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPerson_id() {
		return person_id;
	}
	public void setPerson_id(String person_id) {
		this.person_id = person_id;
	}
	public Person(String age,String name,String person_id)
	{
		super();
		this.age=age;
		this.name=name;
		this.person_id=person_id;
	}
	@Override
	public String toString() {
		return "Person [age=" + age + ", name=" + name + ", person_id=" + person_id + "]";
	}
	
	
}
