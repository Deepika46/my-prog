package com.cg.voting.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.voting.bean.Person;
import com.cg.voting.exceptions.VotingException;
import com.cg.voting.util.DBUtil;


public class VotingDAOImpl implements VotingDAO {
	
	Statement statement = null;
	ResultSet rsSet = null;
	PreparedStatement preparedStatement = null;
	

	@Override
	public ArrayList<String> getName() throws VotingException {
		// TODO Auto-generated method stub
		ArrayList<String> Name = new ArrayList<String>();
		Connection connection = DBUtil.obtainConnection();
		String sql = "SELECT name FROM Person";
		try {
			statement = connection.createStatement();
			rsSet = statement.executeQuery(sql);
			while (rsSet.next()) {
				Name.add(rsSet.getString("Name"));
			}
		} catch (SQLException e) {
			throw new VotingException("Error while database interaction:::"
					+ e.getMessage());
		}
		
		return getName();
	}

	@Override
	public ArrayList<String> search(String Name) throws VotingException {
		// TODO Auto-generated method stub
		ArrayList<String> PersonList = new ArrayList<String>();
		Connection connection = DBUtil.obtainConnection();
		String sql = "SELECT personId,Name,Age FROM Person";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, Name);
			rsSet = preparedStatement.executeQuery();
			while (rsSet.next()) {
				Person p = new Person();
				p.setPerson_id(rsSet.getString("PersonId"));
				p.setName(rsSet.getString("Name"));
				p.setAge(rsSet.getString("Age"));
				
				PersonList.add(Name);
			}
		} catch (SQLException e) {
			throw new VotingException("Error while database interaction:::"
					+ e.getMessage());
		}
		
		return PersonList;
	}

	@Override
	public int insert(Person person, int personId) throws VotingException {
		// TODO Auto-generated method stub
		int person_Id = 0;
		Connection connection = DBUtil.obtainConnection();
		String sequenceSql = "SELECT seq_person_id.nextval FROM DUAL";
		String insertSql = "INSERT INTO Person VALUES(?,?,?,?,?,?)";
		String updateSql = "UPDATE Person SET  WHERE person_id=?";
		PreparedStatement pstmt = null;
		try {
			statement = connection.createStatement();
			rsSet = statement.executeQuery(sequenceSql);
			if (rsSet.next()) {
				person_Id = rsSet.getInt(1);
			}

			preparedStatement = connection.prepareStatement(insertSql);
			preparedStatement.setInt(1, person_Id);
			preparedStatement.setString(2, person.getName());
			preparedStatement.setString(3, person.getAge());
			

			int insertRows = preparedStatement.executeUpdate();

			if (insertRows != 0) {
				pstmt = connection.prepareStatement(updateSql);
				pstmt.setString(1, person.getAge());
				pstmt.setInt(2, person_Id);

				int updateRows = pstmt.executeUpdate();

				if (updateRows != 0) {
					return person_Id;
				}
			}

		} catch (SQLException e) {
			throw new VotingException("Error while database interaction:::"
					+ e.getMessage());
		}
		
		return insert(person, personId);
	}

}
