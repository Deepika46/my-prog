package com.cg.voting.dao;

import java.util.ArrayList;

import com.cg.voting.bean.Person;
import com.cg.voting.exceptions.VotingException;

public interface VotingDAO {
	
	public ArrayList<String> getName() throws VotingException;

	public ArrayList<String> search(String Name)
			throws VotingException;

	public int insert(Person person, int personId)
			throws VotingException;

}
