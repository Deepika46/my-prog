package com.cg.voting.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.voting.bean.Person;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
			PrintWriter pw=response.getWriter();
			String name = request.getParameter("name");
	        String age = request.getParameter("age");
	        String person_id=request.getParameter("person_id");
	        int i=Integer.parseInt(age);
	        Person p=new Person(age, name, person_id);
	        HttpSession sc=request.getSession();
	      //  p.setAge(i);
	      //  request.setAttribute("personObj",p);
	        response.setContentType("index.jsp");
			if(i>=18) 
		{
				 request.setAttribute("personObj",p);
				 RequestDispatcher rd=request.getRequestDispatcher("/success");
				 rd.forward(request, response);
				 response.getWriter().append("served at:").append("request.getContextPath");
				//pw.println("Eligible to vote");
			//	response.sendRedirect("success.jsp");
				 
			}
		else {
				 
	            pw.println("not Eligible to vote");
	         //  response.sendRedirect("error.jsp");
	        }
			
			}
			
		

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doGet(request, response);
	}

}