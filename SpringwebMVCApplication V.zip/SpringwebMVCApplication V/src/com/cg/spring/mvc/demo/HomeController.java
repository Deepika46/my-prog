package com.cg.spring.mvc.demo;

import java.time.LocalDate;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.portlet.ModelAndView;

import com.cg.spring.mvc.demo.beans.Student;
import com.cg.spring.mvc.demo.service.StudentService;


@Controller
public class HomeController {
	
	@Autowired
	StudentService service;
	public StudentService getService() {
		return service;
	}
	public void setService(StudentService service) {
		this.service = service;
	}
	@RequestMapping("displayDate")
	public String displayDate(Model model) {
		System.out.println("in display date method...");
		LocalDate date=LocalDate.now();
		model.addAttribute("today",date);
		return "Home";
		}
	
	
	@RequestMapping("ShowLoginPage")
	public String getLoginPage()
	{
		return "Login";
	}
	
	
   @RequestMapping("login")
   public String ValidateUser(Model model ,
		   @RequestParam("username")String uname,
		   @RequestParam("password")String pass ) {
   if(uname.equals("yogini")&& pass.equals("1234"))
   { 
	   model.addAttribute("successmsg", "welcome to Home Page");
       return "Home";
	   
   }else {
	    model.addAttribute("errormsg","Invalid Username/password");
	    return "Error";
          }
	  
}
   @RequestMapping("ShowRegistrationPage")
	   public String getRegistrationpage(Model model)
   {
	   Student student= new Student();
	   model.addAttribute("studentBean",student);
		   return "Registration";	   
   }
   
   
   
   @RequestMapping("registration")
   public String registration( Model model,
	  @ModelAttribute("studentBean")
	  @Valid Student student, BindingResult result) {
   if(result.hasErrors()){
	   return "Registration";
   }else{
	   student=service.addStudent(student);
	   model.addAttribute("student",student);
	   model.addAttribute("successMsg","Student Added");
	   return "Success";
   }
   }
   }
  


