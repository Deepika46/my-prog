package com.cg.spring.mvc.demo.service;

import com.cg.spring.mvc.demo.beans.Student;

public interface StudentService {
	public Student addStudent(Student student);

}
