package com.cg.spring.mvc.demo.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.mvc.demo.beans.Student;
import com.cg.spring.mvc.repo.StudentRepository;
@Service
@Transactional
public class StudentServiceImpl implements StudentService {
	@Autowired
	StudentRepository repo;

	@Override
	public Student addStudent(Student student) {
		return repo.addStudent(student);
		
	}

	public StudentRepository getRepo() {
		return repo;
	}

	public void setRepo(StudentRepository repo) {
		this.repo = repo;
	}
	

}
