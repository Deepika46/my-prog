package com.cg.spring.mvc.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.spring.mvc.demo.beans.Student;
@Repository
public class StudentRepositoryImpl implements StudentRepository{

	@PersistenceContext
	EntityManager manager;	
	@Override
	public Student addStudent(Student student) {
		manager.persist(student);
		manager.flush();
		return student;
	}

}
