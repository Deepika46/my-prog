package com.cg.pl;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.beans.DBConfiguration;
import com.cg.beans.Person;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Resource rsc = new ClassPathResource("beans.xml");
		//BeanFactory factory = new XmlBeanFactory(rsc);
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
				
		//Person person = (Person) factory.getBean("p1");
		//Person person = context.getBean(Person.class);
		
		//System.out.println(person);
		
		//To display properties
		DBConfiguration config = context.getBean(DBConfiguration.class);
		
		System.out.println(config.getUrl());
		System.out.println(config.getDriver());
		System.out.println(config.getUserName());
		System.out.println(config.getPassword());
		
		
		
	/*	person.setAge(22);
		person.setfirstName("Vinayak");
		person.setlastName("Gawde");
		
		System.out.println(person);*/
		
		
	}

}
