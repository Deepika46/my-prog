package com.cg.beans;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Person {

	private String firstName;
	private String lastName;
	private int age;
	private float height;
	private ArrayList<String> languages = new ArrayList<String>();
	private Address address; 
	private LocalDate birthDate;
	
	public LocalDate getBirthDate() {
		return birthDate;
	}



	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}



	public Person() {
		// TODO Auto-generated constructor stub	
		age = 21;
		firstName = "Swastika";
		lastName = "Shukla";		
	}

	
	
	public float getHeight() {
		return height;
	}



	public void setHeight(float height) {
		this.height = height;
	}



	public Person(String firstName, String lastName) {
		super();
		this.age=21;
		this.firstName = firstName;
		this.lastName = lastName;
	}



	public Person(String firstName, String lastName, int age, float height) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.height = height;
	}

	

	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public Address getAddress() {
		return address;
	}



	public void setAddress(Address address) {
		this.address = address;
	}

	


	public ArrayList<String> getLanguages() {
		return languages;
	}



	public void setLanguages(ArrayList<String> languages) {
		this.languages = languages;
	}



	@Override
	public String toString() {
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		String str = formatter.format(birthDate);
		
		return "First Name = " + firstName + "\nLast Name = " + lastName + "\nAge = " + age + "\nHeight = " + height
				+ "\nLanguages = " + languages + "\nAddress = " + address + "\nBirthDate = " + str;
	}



	
	
	

}
