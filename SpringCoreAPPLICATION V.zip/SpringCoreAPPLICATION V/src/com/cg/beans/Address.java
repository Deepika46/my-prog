package com.cg.beans;

public class Address {

	private String cityName;
	private String streetNo;
	private String pinCode;
	private String areaName;
	
	public Address() {
		// TODO Auto-generated constructor stub
	}

	public Address(String cityName, String streetNo, String pinCode, String areaName) {
		super();
		this.cityName = cityName;
		this.streetNo = streetNo;
		this.areaName = areaName;
		this.pinCode = pinCode;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getStreetNo() {
		return streetNo;
	}

	public void setStreetNo(String streetNo) {
		this.streetNo = streetNo;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	
	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	@Override
	public String toString() {
		return "[City Name=" + cityName + ", Street Name=" + streetNo + ", Area Name="+ areaName + ", Pin Code=" + pinCode +"]";
	}
	
	
	

}
