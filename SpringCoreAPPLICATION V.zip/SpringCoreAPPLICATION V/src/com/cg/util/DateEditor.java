package com.cg.util;

import java.beans.PropertyEditorSupport;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateEditor extends PropertyEditorSupport {

	LocalDate date;
	
	public DateEditor() {
		// TODO Auto-generated constructor stub
	}

	public DateEditor(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getAsText() {
		return date.toString();		
	}
	
	@Override
	public void setAsText(String str) throws IllegalArgumentException{
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		
		date = LocalDate.parse(str, formatter);
		setValue(date);
	}
	
}
